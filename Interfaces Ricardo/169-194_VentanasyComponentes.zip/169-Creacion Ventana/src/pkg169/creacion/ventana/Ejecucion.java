package pkg169.creacion.ventana;

public class Ejecucion {

    public static void main(String[] args) {
        Ventana ventana1 = new Ventana();

        ventana1.setVisible(true); // hacer visible la ventana
    }
}
