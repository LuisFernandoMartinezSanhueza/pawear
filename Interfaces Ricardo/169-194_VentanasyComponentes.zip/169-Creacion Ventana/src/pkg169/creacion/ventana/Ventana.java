package pkg169.creacion.ventana;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;//importa Dimension
import java.awt.Font;
import java.awt.Image;
import java.util.Arrays;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class Ventana extends JFrame {

    JPanel panel = new JPanel(); // instanciar aca

    public Ventana() {
        setTitle("EASY FOOD");
        setBounds(0, 0, 500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(400, 400));
        getContentPane().setBackground(Color.green);

        iniciarComponentes();
    }

    private void iniciarComponentes() {

        colocarPaneles();
        //colocarEtiquetas();
        //colocarBotones();
        //colocarRadioBotones();
        //colocarBotonesActivacion();
        //colocarCajasTexto();
        // colocarAreasTexto();
        //colocarCasillasVerificacion();
        //colocarListasDespegables();
        //colocarCampoContraseña();
        //colocarTablas();
        //colocarListas();
    }

    //aqui interruptor de layout
    private void colocarPaneles() {
        panel.setLayout(null);
        panel.setBackground(Color.white);
        getContentPane().add(panel);
    }

    private void colocarEtiquetas() {
        JLabel etiqueta = new JLabel("CREEPER");
        etiqueta.setBounds(40, 40, 100, 70);
        panel.setLayout(null);

        panel.add(etiqueta);

        etiqueta.setForeground(Color.white);
        etiqueta.setBackground(Color.green);
        etiqueta.setOpaque(true);

        etiqueta.setHorizontalAlignment(SwingConstants.CENTER);

        etiqueta.setFont(new Font("arial", Font.BOLD, 18));

        ImageIcon imagenCambiar = new ImageIcon("178-Creeper.jpg");
        JLabel etiquetaImagen1 = new JLabel();

        etiquetaImagen1.setBounds(80, 90, 300, 300);
        etiquetaImagen1.setIcon(new ImageIcon(imagenCambiar.getImage().getScaledInstance(
                etiquetaImagen1.getWidth(), etiquetaImagen1.getHeight(), Image.SCALE_DEFAULT)));

        panel.add(etiquetaImagen1);
    }

    private void colocarBotones() {

        JButton boton = new JButton();
        boton.setText("Click");
        boton.setBounds(100, 10, 110, 50);
        panel.add(boton);

        boton.setBorder(BorderFactory.createLineBorder(Color.yellow, 2, true));

    }

    private void colocarRadioBotones() {

        JRadioButton radioBoton1 = new JRadioButton("Opcion 1", true);
        radioBoton1.setBounds(50, 100, 100, 50);
        radioBoton1.setEnabled(false);
        radioBoton1.setText("Proga");
        radioBoton1.setFont(new Font("Proga", Font.BOLD, 20));
        panel.add(radioBoton1);

        JRadioButton radioBoton2 = new JRadioButton("Opcion 2", false);
        radioBoton2.setBounds(50, 150, 100, 50);
        panel.add(radioBoton2);

        JRadioButton radioBoton3 = new JRadioButton("Opcion 3", false);
        radioBoton3.setBounds(50, 200, 100, 50);
        panel.add(radioBoton3);

        ButtonGroup grupoRadioBotones = new ButtonGroup();
        grupoRadioBotones.add(radioBoton1);
        grupoRadioBotones.add(radioBoton2);
        grupoRadioBotones.add(radioBoton3);

    }

    private void colocarBotonesActivacion() {

        JToggleButton botonActivacion1 = new JToggleButton("Opcion 1", true);
        botonActivacion1.setBounds(50, 100, 100, 50);
        panel.add(botonActivacion1);

        JToggleButton botonActivacion2 = new JToggleButton("Opcion 1", false);
        botonActivacion2.setBounds(50, 200, 100, 50);
        panel.add(botonActivacion2);

        JToggleButton botonActivacion3 = new JToggleButton("Opcion 1", false);
        botonActivacion3.setBounds(50, 300, 100, 50);
        panel.add(botonActivacion3);

        ButtonGroup grupoBotonesActivado = new ButtonGroup();
        grupoBotonesActivado.add(botonActivacion1);
        grupoBotonesActivado.add(botonActivacion2);
        grupoBotonesActivado.add(botonActivacion3);
    }

    private void colocarCajasTexto() {

        JTextField cajaTexto = new JTextField();
        cajaTexto.setBounds(50, 50, 400, 20);
        panel.add(cajaTexto);

        cajaTexto.setText("shiaa");
        System.out.println("Texto en la caja " + cajaTexto.getText());
        cajaTexto.setColumns(20);
    }

    private void colocarAreasTexto() {

        JTextArea areaTexto = new JTextArea();
        areaTexto.setBounds(20, 20, 300, 200);
        panel.add(areaTexto);

        areaTexto.setText("Escriba el texto aqui...");
        areaTexto.append("\nEscribe por aqui");
        areaTexto.setEditable(true);

        JScrollPane barrasDesplazamiento = new JScrollPane(areaTexto);
        barrasDesplazamiento.setBounds(20, 20, 300, 300);
        panel.add(barrasDesplazamiento);

        barrasDesplazamiento.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

        barrasDesplazamiento.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    }

    private void colocarCasillasVerificacion() {

        System.out.println("Ingrese una opcion");
        JCheckBox casillaVerificacion1 = new JCheckBox("Opcion 1", true);
        casillaVerificacion1.setEnabled(false);
        casillaVerificacion1.setBounds(20, 20, 100, 40);
        panel.add(casillaVerificacion1);

        JCheckBox casillaVerificacion2 = new JCheckBox("Opcion 2");
        casillaVerificacion2.setBounds(20, 50, 100, 40);
        panel.add(casillaVerificacion2);

        JCheckBox casillaVerificacion3 = new JCheckBox("Opcion 3");
        casillaVerificacion3.setBounds(20, 80, 100, 40);
        panel.add(casillaVerificacion3);

        JCheckBox casillaVerificacion4 = new JCheckBox("Opcion 4");
        casillaVerificacion4.setBounds(20, 110, 100, 40);
        panel.add(casillaVerificacion4);
    }

    private void colocarListasDespegables() {

        String[] comidas = {"Churrasco", "Completo", "Lomo a lo pobre", "Chorrillana", "Seleccione una comida"};
        JComboBox listaDespegable1 = new JComboBox(comidas);
        listaDespegable1.setBounds(20, 20, 100, 30);
//   panel.add(listaDespegable1);

        listaDespegable1.addItem("Sopa");
        listaDespegable1.setSelectedItem("Seleccione una comida");

        Persona persona1 = new Persona("Tomas", 23, "Peruano");
        Persona persona0 = new Persona("Busque la persona", 0, "mundo");

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        JComboBox listaDespegable2 = new JComboBox(modelo);

        modelo.addElement(persona0);
        modelo.addElement(persona1);

        listaDespegable2.setBounds(100, 20, 200, 30);
        panel.add(listaDespegable2);

    }

    private void colocarCampoContraseña() {

//192 Campo de contraseña
        JPasswordField campoContraseña = new JPasswordField();
        campoContraseña.setBounds(20, 20, 150, 50);
        panel.add(campoContraseña);

        campoContraseña.setText("holaaaaaaaa"); //pone contraseña manualmente

        String contraseña = "";

        for (int i = 0; i < campoContraseña.getPassword().length; i++) {//recorre todo el arreglo de caracteres
            contraseña += campoContraseña.getPassword()[i];
        }

        System.out.println("Contraseña " + contraseña);//password devuelve char
    }

    private void colocarTablas() {
//193-Tablas
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Comida");//colocarColumnas
        modelo.addColumn("Precio");
        modelo.addColumn("Codigo");//necesita barra desplazamiento para motrar

        String[] comida1 = {"Churrasco", "$2500", "335"};
        String[] comida2 = {"Lomito", "$3000", "345"};
        String[] comida3 = {"Cazuela", "$2500", "355"};

        modelo.addRow(comida1);
        modelo.addRow(comida2);
        modelo.addRow(comida3);

        JTable tabla1 = new JTable(modelo);
        tabla1.setBounds(20, 20, 300, 200);
        panel.add(tabla1);

        JScrollPane barra = new JScrollPane(tabla1, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        barra.setBounds(20, 20, 300, 200);
        panel.add(barra);
    }

    private void colocarListas() {
//194-Listas: siempre están presente 

        //crear objeto
        DefaultListModel modelo = new DefaultListModel();
        
        modelo.addElement(new Persona("Churrasco", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco1", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco2", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco3", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco4", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco5", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco6", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco7", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco8", 2500, "Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco9", 2500, "Italiano")); //ingresar objeto  modelo.addElement(new Persona("Churrasco",2500,"Italiano")); //ingresar objeto
        modelo.addElement(new Persona("Churrasco10", 2500, "Italiano")); //ingresar objeto
        //si se selecciona un elemtento de la lista se selecciona el objeto
        JList lista = new JList(modelo);
        lista.setBounds(20, 20, 300, 300);
        panel.add(lista);
        
        JScrollPane barra = new JScrollPane(lista,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        barra.setBounds(20,20,300,300);
        panel.add(barra);
    }

    
}
